"""Views, one for each Insta485 page."""
from insta485.views.index import show_index
from insta485.views.uploads import show_uploads
import insta485.views.api
